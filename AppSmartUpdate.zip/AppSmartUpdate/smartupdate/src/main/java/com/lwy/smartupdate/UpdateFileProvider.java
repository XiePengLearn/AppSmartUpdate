package com.lwy.smartupdate;

import android.support.v4.content.FileProvider;

/**
 * @author lwy 2018/9/2
 * @version v1.0.0
 * @name UpdateFileProvider
 * @description
 */
public class UpdateFileProvider extends FileProvider {
}
