package com.lwy.smartupdate.api;

/**
 * @author lwy 2018/9/2
 * @version v1.0.0
 * @name IRequest
 * @description
 */
public interface IRequest {

    void cancel();
}
