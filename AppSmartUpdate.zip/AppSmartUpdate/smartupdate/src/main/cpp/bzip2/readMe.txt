﻿bzip2包中文件来来自：
http://www.bzip.org/downloads.html